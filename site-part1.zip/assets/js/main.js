/* La Boîte à Parfums — mouvement du site : film du héros au défilement, révélations, défilement horizontal,
   avis, horaires. GSAP + ScrollTrigger + Lenis sont hébergés dans assets/vendor. La réservation est dans booking.js. */
(() => {
  'use strict';

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const root = document.documentElement;
  const BAP = window.BAP || { groups: [], hours: {}, reviews: [] };
  const CFG = window.BAP_CONFIG || {};
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const hasGsap = typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined';
  const api = { lenis: null, scrollTo: null };
  window.BAP_UI = api;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const smooth = (a, b, v) => { const t = clamp((v - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const pad = n => String(n).padStart(2, '0');
  const HERO_FRAMES = CFG.HERO_FRAMES || 119;

  /* ------------------------------------------------------------------ défilement : Lenis + ScrollTrigger */
  function initScroll() {
    if (!hasGsap) return;
    gsap.registerPlugin(ScrollTrigger);
    ScrollTrigger.config({ ignoreMobileResize: true });
    if (typeof Lenis !== 'undefined' && !reduce) {
      const lenis = new Lenis({ lerp: 0.085, wheelMultiplier: 0.95, smoothWheel: true });
      api.lenis = lenis;
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(t => lenis.raf(t * 1000));
      gsap.ticker.lagSmoothing(0);
    }
    api.scrollTo = (target, opt = {}) => {
      const el = typeof target === 'string' ? $(target) : target;
      if (!el) return;
      if (api.lenis) api.lenis.scrollTo(el, { offset: opt.offset ?? 0, duration: opt.duration || 1.6, easing: t => 1 - Math.pow(1 - t, 4) });
      else el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    };
    $$('a[href^="#"]').forEach(a => {
      const id = a.getAttribute('href');
      if (id.length < 2) return;
      a.addEventListener('click', e => {
        const t = $(id); if (!t) return;
        e.preventDefault();
        if (document.body.classList.contains('menu-open')) toggleMenu(false);
        if (id === '#top') { if (api.lenis) api.lenis.scrollTo(0, { duration: 1.8 }); else scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }); }
        else api.scrollTo(t);
      });
    });
  }

  /* ------------------------------------------------------------------ en-tête, menu, barre mobile */
  const site = $('#site');
  function toggleMenu(open) {
    const menu = $('#menu'), b = $('#burger');
    const on = open === undefined ? !document.body.classList.contains('menu-open') : open;
    if (on) { menu.hidden = false; requestAnimationFrame(() => document.body.classList.add('menu-open')); if (api.lenis) api.lenis.stop(); }
    else { document.body.classList.remove('menu-open'); if (api.lenis) api.lenis.start(); setTimeout(() => { if (!document.body.classList.contains('menu-open')) menu.hidden = true; }, 900); }
    b.setAttribute('aria-expanded', String(on)); b.setAttribute('aria-label', on ? 'Fermer le menu' : 'Ouvrir le menu');
  }
  $('#burger').addEventListener('click', () => toggleMenu());
  addEventListener('keydown', e => { if (e.key === 'Escape' && document.body.classList.contains('menu-open')) toggleMenu(false); });

  function initHeader() {
    const track = $('#heroTrack'), mbar = $('#mbar'), book = $('#reserver');
    let last = 0, lastDir = 0;
    const onScroll = y => {
      const heroEnd = track.offsetTop + track.offsetHeight - innerHeight * 0.6;
      const inHero = y < heroEnd;
      site.classList.toggle('is-solid', !inHero);
      const dir = y > last ? 1 : y < last ? -1 : lastDir;
      if (!inHero && Math.abs(y - last) > 4) site.classList.toggle('is-hidden', dir > 0 && y > 600);
      else if (inHero) site.classList.remove('is-hidden');
      lastDir = dir; last = y;
      // barre mobile : après le héros, masquée pendant la réservation
      const bb = book.getBoundingClientRect();
      const inBook = bb.top < innerHeight * 0.7 && bb.bottom > innerHeight * 0.3;
      mbar.classList.toggle('is-on', !inHero && !inBook);
    };
    if (api.lenis) api.lenis.on('scroll', e => onScroll(e.scroll)); else addEventListener('scroll', () => onScroll(scrollY), { passive: true });
    onScroll(scrollY);
    // lien actif
    const links = $$('.nav a');
    $$('main section[id]').forEach(sec => {
      const link = links.find(l => l.getAttribute('href') === '#' + sec.id);
      if (!link || !hasGsap) return;
      ScrollTrigger.create({ trigger: sec, start: 'top 55%', end: 'bottom 45%', onToggle: s => link.classList.toggle('is-on', s.isActive) });
    });
    if (hasGsap) gsap.to('#progress i', { scaleX: 1, ease: 'none', scrollTrigger: { start: 0, end: 'max', scrub: 0.2 } });
  }

  /* ------------------------------------------------------------------ héros : la vidéo avance quand on fait défiler */
  const stage = $('#heroStage'), canvas = $('#heroCanvas'), hero = $('.hero');
  const ctx = canvas.getContext('2d', { alpha: false });
  const H = { frames: [], loaded: 0, count: HERO_FRAMES, cur: 0, target: 0, progress: 0, w: 0, h: 0, dpr: 1, portrait: false, zoom: 1, dirty: true, ok: false };
  const portrait = () => innerWidth < 760 || innerHeight > innerWidth;
  const frameURL = i => (H.portrait ? 'assets/frames-m/m-' : 'assets/frames/d-') + pad3(i + 1) + '.webp';
  const pad3 = n => String(n).padStart(3, '0');

  function sizeCanvas() {
    H.dpr = Math.min(devicePixelRatio || 1, 2);
    H.w = stage.clientWidth; H.h = stage.clientHeight;
    canvas.width = Math.round(H.w * H.dpr); canvas.height = Math.round(H.h * H.dpr);
    H.dirty = true;
  }
  function drawImg(img, alpha) {
    if (!img || !img.naturalWidth) return;
    const cw = canvas.width, ch = canvas.height;
    const s = Math.max(cw / img.naturalWidth, ch / img.naturalHeight) * H.zoom;
    const dw = img.naturalWidth * s, dh = img.naturalHeight * s;
    ctx.globalAlpha = alpha;
    // le sujet se décale légèrement vers le haut quand la caméra avance
    ctx.drawImage(img, (cw - dw) / 2, (ch - dh) / 2 - H.progress * ch * 0.025, dw, dh);
  }
  const have = i => H.frames[i] && H.frames[i].complete && H.frames[i].naturalWidth > 0;
  function below(i) { for (let k = i; k >= 0; k--) if (have(k)) return k; for (let k = i + 1; k < H.count; k++) if (have(k)) return k; return -1; }
  function above(i) { for (let k = i; k < H.count; k++) if (have(k)) return k; for (let k = i - 1; k >= 0; k--) if (have(k)) return k; return -1; }
  function render() {
    if (!H.ok) return;
    const f = Math.floor(H.cur), c = Math.min(H.count - 1, f + 1);
    const i0 = below(f), i1 = above(c);
    if (i0 < 0) return;
    ctx.globalCompositeOperation = 'source-over';
    drawImg(H.frames[i0], 1);
    if (i1 >= 0 && i1 !== i0) {
      const a = clamp((H.cur - i0) / (i1 - i0), 0, 1);
      if (a > 0.004) drawImg(H.frames[i1], a);
    }
    ctx.globalAlpha = 1;
  }
  function heroTick() {
    const d = H.target - H.cur;
    if (Math.abs(d) > 0.002 || H.dirty) { H.cur += d * 0.16; if (Math.abs(H.target - H.cur) < 0.002) H.cur = H.target; H.dirty = false; render(); }
  }
  function loadFrames(onEssential, onProgress) {
    H.portrait = portrait();
    sizeCanvas();
    H.frames = new Array(H.count);
    const step = 6;
    const essential = []; for (let i = 0; i < H.count; i += step) essential.push(i);
    if (essential[essential.length - 1] !== H.count - 1) essential.push(H.count - 1);
    const rest = []; for (let i = 0; i < H.count; i++) if (!essential.includes(i)) rest.push(i);
    const queue = essential.concat(rest);
    let essentialLeft = essential.length, qi = 0, active = 0, failed = 0;
    const next = () => {
      while (active < 6 && qi < queue.length) {
        const i = queue[qi++]; active++;
        const img = new Image(); img.decoding = 'async';
        let tries = 0;
        img.onload = img.onerror = ev => {
          if (ev.type === 'error' && tries < 2) { tries++; setTimeout(() => { img.src = frameURL(i) + '?r=' + tries; }, 400 * tries); return; }   // une coupure de connexion : on réessaie
          if (ev.type === 'error') failed++; else { H.loaded++; H.dirty = true; }
          active--;
          if (essential.includes(i)) { essentialLeft--; onProgress && onProgress((essential.length - essentialLeft) / essential.length); if (essentialLeft === 0) onEssential(failed < essential.length / 2); }
          next();
        };
        img.src = frameURL(i);
        H.frames[i] = img;
      }
    };
    next();
  }

  const chapters = $$('#chapters .chapter');
  const content = $('#heroContent');
  function setProgress(p) {
    H.progress = p;
    H.target = p * (H.count - 1);
    H.zoom = 1 + 0.13 * p;
    H.dirty = true;
    const out = 1 - smooth(0.015, 0.13, p);
    gsap.set(content, { opacity: out, y: -p * 220, pointerEvents: out < 0.2 ? 'none' : 'auto' });
    chapters.forEach(ch => {
      const from = +ch.dataset.from, to = +ch.dataset.to, len = to - from;
      const t = clamp((p - from) / len, 0, 1);
      const o = (p < from || p > to) ? 0 : smooth(0, 0.16, t) * (1 - smooth(0.84, 1, t) * (to > 1 ? 0 : 1));
      gsap.set(ch, { opacity: o, y: (1 - smooth(0, 0.16, t)) * 36 - smooth(0.84, 1, t) * 30 * (to > 1 ? 0 : 1), visibility: o > 0.01 ? 'visible' : 'hidden' });
    });
    const idx = p < 0.39 ? 1 : p < 0.73 ? 2 : 3;
    const mn = $('#meterN'); if (mn.textContent !== pad(idx)) mn.textContent = pad(idx);
    $('#meter i').style.setProperty('--p', (p * 100).toFixed(1) + '%');
    gsap.set('#heroScroll', { opacity: 1 - smooth(0.01, 0.06, p) });
    $('#heroScroll').style.pointerEvents = p > 0.05 ? 'none' : '';
  }

  /* poussière dorée : quelques particules lentes (pause hors écran) */
  function initDust() {
    const cv = $('#heroDust'); if (!cv || reduce) return;
    const c = cv.getContext('2d'); let w = 0, h = 0, run = true;
    const P = Array.from({ length: innerWidth < 760 ? 22 : 46 }, () => ({ x: Math.random(), y: Math.random(), r: Math.random() * 1.8 + .4, s: Math.random() * .00012 + .00003, a: Math.random() * Math.PI * 2, o: Math.random() * .6 + .2 }));
    const size = () => { const d = Math.min(devicePixelRatio || 1, 1.5); w = cv.width = Math.round(stage.clientWidth * d); h = cv.height = Math.round(stage.clientHeight * d); };
    size(); addEventListener('resize', size);
    new IntersectionObserver(([e]) => { run = e.isIntersecting; }).observe(stage);
    gsap.ticker.add((t) => {
      if (!run) return;
      c.clearRect(0, 0, w, h);
      for (const p of P) {
        p.y -= p.s * 16.6; p.x += Math.sin(t * .4 + p.a) * .00006; if (p.y < -.02) { p.y = 1.02; p.x = Math.random(); }
        const g = c.createRadialGradient(p.x * w, p.y * h, 0, p.x * w, p.y * h, p.r * 5 * (w / 1600 + .4));
        g.addColorStop(0, 'rgba(255,226,170,' + (p.o * (.5 + .5 * Math.sin(t * 1.2 + p.a))) + ')'); g.addColorStop(1, 'rgba(255,226,170,0)');
        c.fillStyle = g; c.beginPath(); c.arc(p.x * w, p.y * h, p.r * 5 * (w / 1600 + .4), 0, 7); c.fill();
      }
    });
  }

  /* ------------------------------------------------------------------ texte : découpage en mots */
  function splitWords(el) {
    const out = document.createDocumentFragment();
    const walk = (node, target) => node.childNodes.forEach(n => {
      if (n.nodeType === 3) {
        n.textContent.split(/(\s+)/).forEach(tok => {
          if (!tok) return;
          if (/^\s+$/.test(tok)) target.appendChild(document.createTextNode(' '));
          else { const sw = document.createElement('span'); sw.className = 'sw'; const i = document.createElement('span'); i.textContent = tok; sw.appendChild(i); target.appendChild(sw); }
        });
      } else if (n.nodeType === 1) { const c = n.cloneNode(false); target.appendChild(c); walk(n, c); }
    });
    walk(el, out);
    el.textContent = ''; el.appendChild(out);
    return $$('.sw>span', el);
  }

  /* ------------------------------------------------------------------ animations de défilement */
  function initReveals() {
    // titres
    $$('[data-split]').forEach(el => {
      const label = el.textContent.replace(/\s+/g, ' ').trim();
      const words = splitWords(el); el.setAttribute('aria-label', label);
      $$('.sw', el).forEach(s => s.setAttribute('aria-hidden', 'true'));
      gsap.set(words, { yPercent: 118 });
      ScrollTrigger.create({ trigger: el, start: 'top 86%', once: true, onEnter: () => gsap.to(words, { yPercent: 0, duration: 1.15, ease: 'power4.out', stagger: 0.07 }) });
    });
    // fondus
    $$('[data-reveal]').forEach(el => {
      ScrollTrigger.create({ trigger: el, start: 'top 90%', once: true, onEnter: () => gsap.to(el, { opacity: 1, y: 0, duration: 1.1, ease: 'power3.out', delay: (+el.dataset.delay || 0) }) });
    });
    // images qui se dévoilent
    $$('[data-clip]').forEach(fig => {
      ScrollTrigger.create({ trigger: fig, start: 'top 88%', once: true, onEnter: () => gsap.to(fig, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.5, ease: 'power3.inOut' }) });
    });
    // parallaxe douce des photos
    if (!reduce) $$('[data-parallax]').forEach(img => {
      const k = parseFloat(img.dataset.parallax) || 0.08;
      gsap.set(img, { scale: 1 + Math.abs(k) * 2.4 + 0.06 });
      gsap.fromTo(img, { yPercent: -k * 100 }, { yPercent: k * 100, ease: 'none', scrollTrigger: { trigger: img.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } });
    });
    // manifeste : mots qui s'allument
    const man = $('#manifesto');
    if (man) {
      const ws = [];
      const wrap = node => node.childNodes.forEach(n => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach(tok => { if (!tok) return; if (/^\s+$/.test(tok)) frag.appendChild(document.createTextNode(' ')); else { const s = document.createElement('span'); s.className = 'w'; s.textContent = tok; ws.push(s); frag.appendChild(s); } });
          n.replaceWith(frag);
        } else if (n.nodeType === 1) wrap(n);
      });
      wrap(man);
      gsap.to(ws, { opacity: 1, ease: 'none', stagger: 0.12, scrollTrigger: { trigger: man, start: 'top 82%', end: 'bottom 52%', scrub: 0.4 } });
    }
    // chiffres
    $$('[data-count]').forEach(el => {
      const to = parseFloat(el.dataset.count), dec = +el.dataset.dec || 0, o = { v: 0 };
      const fmt = v => v.toFixed(dec).replace('.', ',');
      el.textContent = fmt(0);
      ScrollTrigger.create({ trigger: el, start: 'top 92%', once: true, onEnter: () => gsap.to(o, { v: to, duration: 2.2, ease: 'power3.out', onUpdate: () => { el.textContent = fmt(o.v); } }) });
    });
  }

  function initMarquee() {
    const row = $('#marquee'); if (!row || reduce) return;
    const half = () => row.scrollWidth / 2;
    const tw = gsap.to(row, { x: () => -half(), duration: 46, ease: 'none', repeat: -1 });
    ScrollTrigger.create({ onUpdate: self => { const v = self.getVelocity(); const k = clamp(Math.abs(v) / 500, 0, 5); gsap.to(tw, { timeScale: (v < 0 ? -1 : 1) * (1 + k), duration: 0.4, overwrite: true }); gsap.to(tw, { timeScale: 1, duration: 1.4, delay: 0.3, overwrite: 'auto' }); } });
  }

  function initCare() {
    const track = $('#careTrack'), pin = $('#carePin'), bar = $('#careBar');
    if (!track || reduce) return;
    gsap.matchMedia().add('(min-width: 901px)', () => {
      const dist = () => Math.max(0, track.scrollWidth - document.documentElement.clientWidth);
      const tween = gsap.to(track, {
        x: () => -dist(), ease: 'none',
        scrollTrigger: { trigger: pin, start: 'top top', end: () => '+=' + dist(), pin: true, scrub: 0.7, anticipatePin: 1, invalidateOnRefresh: true, onUpdate: s => { bar.style.transform = 'scaleX(' + s.progress.toFixed(4) + ')'; } }
      });
      // les photos glissent légèrement à l'intérieur de leur cadre pendant le défilement horizontal
      $$('.panel>img').forEach(img => {
        gsap.set(img, { scale: 1.16 });
        gsap.fromTo(img, { xPercent: -5 }, { xPercent: 5, ease: 'none', scrollTrigger: { trigger: img.parentElement, containerAnimation: tween, start: 'left right', end: 'right left', scrub: true } });
      });
    });
  }

  function initGiftTilt() {
    const wrap = $('#giftTilt'), card = $('.giftcard'); if (!wrap || !card || !fine) return;
    wrap.addEventListener('pointermove', e => {
      const r = wrap.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      card.classList.add('is-tilting');
      card.style.setProperty('--ry', (x * 16).toFixed(2) + 'deg'); card.style.setProperty('--rx', (-y * 12).toFixed(2) + 'deg');
      card.style.setProperty('--mx', ((x + .5) * 100).toFixed(1) + '%'); card.style.setProperty('--my', ((y + .5) * 100).toFixed(1) + '%');
    });
    wrap.addEventListener('pointerleave', () => { card.classList.remove('is-tilting'); card.style.setProperty('--ry', '0deg'); card.style.setProperty('--rx', '0deg'); });
  }

  /* ------------------------------------------------------------------ avis */
  function initReviews() {
    const rail = $('#revRail'); if (!rail) return;
    const star = '<svg class="i star" aria-hidden="true"><use href="#i-star"/></svg>';
    rail.innerHTML = (BAP.reviews || []).map(r => '<article class="rev"><span class="stars" role="img" aria-label="5 étoiles sur 5">' + star.repeat(5) + '</span><p>' + r.text.replace(/</g, '&lt;') + '</p><footer><span class="av" aria-hidden="true">' + r.name.charAt(0) + '</span><span><b>' + r.name + '</b><small>' + (r.guide ? 'Local Guide · ' : '') + (r.when ? 'visite en ' + r.when : 'avis Google') + '</small></span></footer></article>').join('');
    const step = () => Math.min(rail.clientWidth * 0.85, 460);
    $('#revNext').addEventListener('click', () => rail.scrollBy({ left: step(), behavior: 'smooth' }));
    $('#revPrev').addEventListener('click', () => rail.scrollBy({ left: -step(), behavior: 'smooth' }));
    // glisser à la souris
    let down = false, sx = 0, sl = 0, moved = 0;
    rail.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse') return; down = true; sx = e.clientX; sl = rail.scrollLeft; moved = 0; });
    addEventListener('pointermove', e => { if (!down) return; const dx = e.clientX - sx; moved = Math.max(moved, Math.abs(dx)); if (moved > 4) { rail.classList.add('is-drag'); rail.scrollLeft = sl - dx; } });
    addEventListener('pointerup', () => { down = false; rail.classList.remove('is-drag'); });
    if (hasGsap) gsap.from('.rev', { y: 60, opacity: 0, duration: 1.1, ease: 'power3.out', stagger: 0.09, scrollTrigger: { trigger: rail, start: 'top 85%', once: true } });
  }

  /* ------------------------------------------------------------------ horaires et « ouvert maintenant » */
  const DAYS = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  const hfmt = s => { const [h, m] = s.split(':').map(Number); return h + ' h' + (m ? ' ' + pad(m) : ''); };
  const toMin = s => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
  function parisNow() {
    const p = {};
    new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Paris', hourCycle: 'h23', weekday: 'short', hour: '2-digit', minute: '2-digit' }).formatToParts(new Date()).forEach(x => { p[x.type] = x.value; });
    const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(p.weekday);
    return { day: wd, min: +p.hour * 60 + +p.minute };
  }
  function initHours() {
    const tb = $('#hoursTable tbody'); if (!tb) return;
    const now = parisNow();
    tb.innerHTML = [1, 2, 3, 4, 5, 6, 0].map(d => {
      const h = BAP.hours[d];
      return '<tr class="' + (d === now.day ? 'is-today' : '') + (h ? '' : ' is-shut') + '"><td>' + DAYS[d] + '</td><td>' + (h ? h.map(r => hfmt(r[0]) + ' – ' + hfmt(r[1])).join(' · ') : 'Fermé') + '</td></tr>';
    }).join('');
    const el = $('#openNow'); const today = BAP.hours[now.day] || [];
    const cur = today.find(r => now.min >= toMin(r[0]) && now.min < toMin(r[1]));
    if (cur) { el.className = 'open is-open'; el.textContent = 'Ouvert maintenant · jusqu’à ' + hfmt(cur[1]); return; }
    let next = null;
    for (let k = 0; k < 8 && !next; k++) {
      const d = (now.day + k) % 7, rs = BAP.hours[d] || [];
      const r = rs.find(x => k > 0 || toMin(x[0]) > now.min);
      if (r) next = { k, d, t: r[0] };
    }
    el.className = 'open is-closed';
    el.textContent = next ? 'Fermé · réouverture ' + (next.k === 0 ? 'aujourd’hui' : next.k === 1 ? 'demain' : DAYS[next.d].toLowerCase()) + ' à ' + hfmt(next.t) : 'Fermé';
  }

  /* ------------------------------------------------------------------ curseur et boutons magnétiques */
  function initCursor() {
    if (!fine || reduce) return;
    const cur = $('#cursor'), dot = $('.cursor__dot'), ring = $('.cursor__ring'), label = $('#cursorLabel');
    root.classList.add('has-cursor');
    let x = innerWidth / 2, y = innerHeight / 2, rx = x, ry = y;
    addEventListener('pointermove', e => { x = e.clientX; y = e.clientY; });
    gsap.ticker.add(() => {
      rx += (x - rx) * .16; ry += (y - ry) * .16;
      dot.style.transform = 'translate(' + x + 'px,' + y + 'px)'; ring.style.transform = 'translate(' + rx + 'px,' + ry + 'px)';
    });
    const sel = 'a, button, summary, label, [data-magnetic], .rev, .panel, .cday, .slot, .mrow__add';
    document.addEventListener('pointerover', e => {
      const t = e.target.closest(sel + ', #revRail');
      cur.classList.toggle('is-link', !!t && !t.matches('#revRail, .panel'));
      const lab = e.target.closest('.panel') ? 'Voir' : e.target.closest('#revRail .rev, #revRail') ? 'Glisser' : '';
      label.textContent = lab; cur.classList.toggle('is-label', !!lab);
    });
    addEventListener('pointerdown', () => cur.classList.add('is-down')); addEventListener('pointerup', () => cur.classList.remove('is-down'));
    $$('[data-magnetic]').forEach(b => {
      const qx = gsap.quickTo(b, 'x', { duration: .5, ease: 'power3' }), qy = gsap.quickTo(b, 'y', { duration: .5, ease: 'power3' });
      b.addEventListener('pointermove', e => { const r = b.getBoundingClientRect(); qx((e.clientX - r.left - r.width / 2) * .22); qy((e.clientY - r.top - r.height / 2) * .32); });
      b.addEventListener('pointerleave', () => { qx(0); qy(0); });
    });
  }

  /* ------------------------------------------------------------------ boutons « Réserver ce soin » */
  function initGroupButtons() {
    $$('[data-open-group]').forEach(b => b.addEventListener('click', () => {
      if (window.BAP_Booking) window.BAP_Booking.openGroup(b.dataset.openGroup);
    }));
  }

  /* ------------------------------------------------------------------ entrée en scène */
  function intro() {
    const tl = gsap.timeline({ defaults: { ease: 'power4.out' } });
    tl.to('.hero__title .line>span', { yPercent: 0, duration: 1.5, stagger: 0.14 }, 0.15)
      .to('.hero__kicker', { opacity: 1, duration: 1.2 }, 0.1)
      .to('.hero__lead', { opacity: 1, duration: 1.2 }, 0.7)
      .to('.hero__cta', { opacity: 1, duration: 1.2 }, 0.85)
      .to('.hero__rate', { opacity: 1, duration: 1.2 }, 1.0)
      .to('.hero__scroll', { opacity: 1, duration: 1.2 }, 1.2)
      .to('.meter', { opacity: 1, duration: 1.2 }, 1.2)
      .add(() => site.classList.add('is-in'), 0.5);
  }

  /* ------------------------------------------------------------------ démarrage */
  const loaderEl = $('#loader'), bar = $('#loaderBar'), pct = $('#loaderPct'), curtain = $('#curtain');
  let revealed = false;
  function reveal() {
    if (revealed) return; revealed = true;
    hero.classList.add('is-ready');
    loaderEl.classList.add('is-out');
    curtain.classList.add('is-open');
    document.body.classList.remove('is-loading');
    setTimeout(() => { curtain.classList.add('is-gone'); loaderEl.remove(); }, 1500);
    if (hasGsap) { intro(); ScrollTrigger.refresh(); }
    else { site.classList.add('is-in'); }
  }

  function start() {
    if (!hasGsap) { // sans GSAP : page statique lisible
      loaderEl.remove(); curtain.remove(); document.body.classList.remove('is-loading');
      initHours(); initReviews(); return;
    }
    root.classList.add('js-ready');
    gsap.set('.hero__title .line>span', { yPercent: 112 });
    initScroll();
    initHeader();
    initReveals();
    initMarquee();
    initCare();
    initGiftTilt();
    initReviews();
    initHours();
    initGroupButtons();
    initCursor();
    initDust();
    // film du héros
    const t0 = performance.now();
    const MIN = reduce ? 200 : 1900;
    let essentialOK = null;
    const done = () => { const wait = Math.max(0, MIN - (performance.now() - t0)); setTimeout(reveal, wait); };
    loadFrames(ok => { essentialOK = ok; H.ok = ok && !reduce; sizeCanvas(); H.dirty = true; heroTick(); (document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(done); }, p => {
      bar.style.width = Math.round(p * 100) + '%'; pct.textContent = Math.round(p * 100) + ' %';
    });
    setTimeout(() => { H.ok = H.ok || (H.loaded > 3 && !reduce); reveal(); }, 9000);       // filet de sécurité : connexion très lente
    ScrollTrigger.create({ trigger: '#heroTrack', start: 'top top', end: 'bottom bottom', onUpdate: s => setProgress(s.progress) });
    setProgress(0);
    gsap.ticker.add(heroTick);
    addEventListener('resize', () => { const p = portrait(); if (p !== H.portrait) { H.portrait = p; } sizeCanvas(); });
    addEventListener('load', () => ScrollTrigger.refresh());
    if (reduce) { gsap.set(content, { opacity: 1 }); }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();

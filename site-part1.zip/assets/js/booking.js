/* La Boîte à Parfums — réservation en ligne (soins → date et heure → coordonnées → règlement) et carte cadeau.
   Réglages : assets/js/config.js · soins, prix, horaires : assets/js/data.js
   Contrats Make (agenda Google) et Stripe : RESERVATION-AGENDA.md et worker/README.md. */
(() => {
  'use strict';

  const CFG = window.BAP_CONFIG || {};
  const D = window.BAP || { groups: [], hours: {}, policy: {} };
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const pad = n => String(n).padStart(2, '0');
  const eur = n => n.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
  const eurC = c => (c % 100 ? (c / 100).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' }) : eur(c / 100));
  const root = $('#reserver');
  if (!root) return;
  const UI = () => window.BAP_UI || {};
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');

  /* ---------- données ---------- */
  const ITEMS = {};
  D.groups.forEach(g => g.items.forEach(i => { ITEMS[i.id] = Object.assign({ group: g.id, groupTitle: g.title }, i); }));
  const POL = Object.assign({ depositPct: 30, cancelHours: 24, lateArrivalMin: 15 }, D.policy);
  const priced = id => ITEMS[id].price != null;
  /* Prix en euros entiers : l'acompte (30 %) est exact en centimes, ex. 25 € → 7,50 €. */
  const depositCents = euros => Math.round(euros * POL.depositPct);
  const fmtDur = m => (m < 60 ? m + ' min' : Math.floor(m / 60) + ' h' + (m % 60 ? ' ' + pad(m % 60) : ''));

  /* ---------- dates (chaînes AAAA-MM-JJ, calculs à midi) ---------- */
  const keyOf = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const parse = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d, 12); };
  const addDays = (k, n) => { const d = parse(k); d.setDate(d.getDate() + n); return keyOf(d); };
  const monthStart = k => k.slice(0, 8) + '01';
  const addMonths = (k, n) => { const d = parse(k); d.setDate(1); d.setMonth(d.getMonth() + n); return keyOf(d); };
  const fmtLong = k => parse(k).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const fmtShort = k => parse(k).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
  const fmtHour = t => Math.floor(t / 60) + '\u00a0h\u00a0' + pad(t % 60);
  const hhmm = m => pad(Math.floor(m / 60)) + ':' + pad(m % 60);
  const toMin = s => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
  /* L'institut raisonne en heure de Paris, quel que soit le fuseau du navigateur (touristes comprises). */
  const parisFmt = (() => { try { return new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Paris', hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); } catch (e) { return null; } })();
  const parisParts = t => { const p = {}; for (const x of parisFmt.formatToParts(new Date(t))) p[x.type] = x.value; return p; };
  const parisWall = t => { const p = parisParts(t); return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute); };
  /* « jour AAAA-MM-JJ + minutes depuis minuit, heure de Paris » → instant en millisecondes (heure d'été comprise) */
  const parisAt = (k, min) => {
    if (!parisFmt) { const d = parse(k); d.setHours(0, min, 0, 0); return d.getTime(); }
    const [y, m, d] = k.split('-').map(Number);
    const w = Date.UTC(y, m - 1, d, Math.floor(min / 60), min % 60);
    let t = w - (parisWall(w) - w); t = w - (parisWall(t) - t);
    return t;
  };
  const todayKey = parisFmt ? (p => p.year + '-' + p.month + '-' + p.day)(parisParts(Date.now())) : keyOf(new Date());
  const rangesOf = k => (D.hours[parse(k).getDay()] || []).map(r => [toMin(r[0]), toMin(r[1])]);

  /* ---------- état ---------- */
  const S = { group: D.groups[0] ? D.groups[0].id : '', cart: [], date: null, time: null, step: 1, month: monthStart(todayKey), busy: null, sending: false, ref: '', pay: 'deposit' };
  const total = () => S.cart.reduce((a, id) => a + (ITEMS[id].price || 0), 0);
  const totalMin = () => S.cart.reduce((a, id) => a + ITEMS[id].min, 0);
  const allPriced = () => S.cart.length > 0 && S.cart.every(priced);
  const unpricedCount = () => S.cart.filter(id => !priced(id)).length;
  const onlineAllowed = () => (CFG.PAYMENT_MODE || 'demo') !== 'onsite' && allPriced();

  /* ---------- étape 1 : carte des soins ---------- */
  const tabs = $('#tabs'), list = $('#menuList');
  function buildMenu() {
    tabs.innerHTML = D.groups.map(g => '<button type="button" class="tab' + (g.id === S.group ? ' is-on' : '') + '" role="tab" data-g="' + g.id + '" aria-selected="' + (g.id === S.group) + '">' + g.title + '<sup data-n="' + g.id + '"></sup></button>').join('');
    list.innerHTML = D.groups.map(g => '<section class="mgroup' + (g.id === S.group ? ' is-on' : '') + '" data-g="' + g.id + '" aria-label="' + esc(g.title) + '">' +
      '<div class="mgroup__head"><span class="mgroup__k">' + g.kicker + '</span><h3>' + g.title + '</h3><p>' + g.intro + '</p></div>' +
      g.items.map(row).join('') +
      '</section>').join('') + '<p class="mnote">Durées indicatives. Les soins « sur demande » sont confirmés par Édith : le règlement se fait alors à l’institut.</p>';
  }
  function row(i) {
    const price = i.price != null ? '<span class="mrow__price">' + eur(i.price) + '</span>' : '<span class="mrow__price is-ask">Sur demande</span>';
    return '<article class="mrow" data-id="' + i.id + '"><div><h4 class="mrow__name">' + i.name + '</h4>' + (i.desc ? '<button type="button" class="mrow__more" aria-expanded="false">En savoir plus</button>' : '') + '</div>' +
      '<div class="mrow__right"><div class="mrow__meta"><span>env. ' + fmtDur(i.min) + '</span>' + price + '</div>' +
      '<button type="button" class="mrow__add" aria-pressed="false" aria-label="Ajouter : ' + esc(i.name) + '"><svg class="i" aria-hidden="true"><use href="#i-plus"/></svg></button></div>' +
      (i.desc ? '<p class="mrow__desc">' + esc(i.desc) + '</p>' : '') + '</article>';
  }
  tabs.addEventListener('click', e => { const b = e.target.closest('.tab'); if (b) setGroup(b.dataset.g); });
  function setGroup(id) {
    S.group = id;
    $$('.tab', tabs).forEach(t => { const on = t.dataset.g === id; t.classList.toggle('is-on', on); t.setAttribute('aria-selected', String(on)); });
    $$('.mgroup', list).forEach(g => g.classList.toggle('is-on', g.dataset.g === id));
  }
  list.addEventListener('click', e => {
    const more = e.target.closest('.mrow__more');
    if (more) { const r = more.closest('.mrow'); const open = r.classList.toggle('is-open'); more.setAttribute('aria-expanded', String(open)); more.textContent = open ? 'Réduire' : 'En savoir plus'; return; }
    const add = e.target.closest('.mrow__add'); if (!add) return;
    toggle(add.closest('.mrow').dataset.id);
  });
  let warnTimer;
  function toggle(id) {
    const i = S.cart.indexOf(id);
    if (i >= 0) S.cart.splice(i, 1);
    else {
      if (totalMin() + ITEMS[id].min > (CFG.MAX_TOTAL_MIN || 240)) { warn('Un rendez-vous ne peut pas dépasser ' + fmtDur(CFG.MAX_TOTAL_MIN || 240) + '. Retirez un soin ou réservez un second rendez-vous.'); return; }
      S.cart.push(id);
    }
    if (S.date && S.time != null && !slotsFor(S.date).includes(S.time)) S.time = null;   // la durée a changé
    refresh();
  }
  function warn(msg) {
    const el = $('#sumList'); let w = $('#sumWarn');
    if (!w) { w = document.createElement('li'); w.id = 'sumWarn'; w.className = 'sum__empty'; w.style.color = '#ffb4a8'; el.appendChild(w); }
    w.textContent = msg; clearTimeout(warnTimer); warnTimer = setTimeout(() => w.remove(), 5000);
  }

  /* ---------- récapitulatif ---------- */
  function refresh() {
    $$('.mrow', list).forEach(r => {
      const on = S.cart.includes(r.dataset.id);
      r.classList.toggle('is-sel', on);
      const b = $('.mrow__add', r); b.setAttribute('aria-pressed', String(on));
      b.innerHTML = '<svg class="i" aria-hidden="true"><use href="#' + (on ? 'i-check' : 'i-plus') + '"/></svg>';
    });
    D.groups.forEach(g => { const n = S.cart.filter(id => ITEMS[id].group === g.id).length; const s = $('[data-n="' + g.id + '"]', tabs); if (s) s.textContent = n || ''; });
    $('#sumList').innerHTML = S.cart.length ? S.cart.map(id => '<li><span>' + ITEMS[id].name + '<br><small>env. ' + fmtDur(ITEMS[id].min) + '</small></span><span><b>' + (priced(id) ? eur(ITEMS[id].price) : 'sur demande') + '</b><button type="button" data-rm="' + id + '" aria-label="Retirer ' + esc(ITEMS[id].name) + '">×</button></span></li>').join('') : '<li class="sum__empty">Aucun soin sélectionné.</li>';
    $('#sumDur').textContent = S.cart.length ? 'env. ' + fmtDur(totalMin()) : '0 min';
    const t = total(), un = unpricedCount();
    $('#sumTotal').textContent = !S.cart.length ? eur(0) : (t === 0 ? 'Sur demande' : eur(t) + (un ? ' + …' : ''));
    const depRow = $('#sumDepRow'); depRow.hidden = !onlineAllowed();
    $('#sumDeposit').textContent = eurC(depositCents(t));
    const note = $('#sumNote');
    note.hidden = !un; note.textContent = un ? (un === 1 ? '1 soin est « sur demande »' : un + ' soins sont « sur demande »') + ' : son tarif est confirmé par Édith et le règlement se fait à l’institut.' : '';
    $$('[data-delay]').forEach(el => { el.textContent = POL.cancelHours + '\u00a0h'; });
    $$('[data-late]').forEach(el => { el.textContent = POL.lateArrivalMin + '\u00a0min'; });
    $$('[data-pct]').forEach(el => { el.textContent = POL.depositPct; });
    const when = $('#sumWhenRow');
    if (S.date && S.time != null) { when.hidden = false; $('#sumWhen').textContent = fmtShort(S.date) + ' · ' + fmtHour(S.time); } else when.hidden = true;
    nav();
  }
  $('#sumList').addEventListener('click', e => { const b = e.target.closest('[data-rm]'); if (b) toggle(b.dataset.rm); });

  /* ---------- navigation entre étapes ---------- */
  const btnNext = $('#btnNext'), btnBack = $('#btnBack'), btnLabel = $('#btnNextLabel');
  function nav() {
    const s = S.step;
    btnBack.hidden = s === 1 || s === 5;
    $('#flowSide').hidden = s === 5;
    btnLabel.textContent = { 1: 'Choisir la date', 2: 'Mes informations', 3: 'Passer au règlement', 4: '' }[s] || '';
    btnNext.hidden = s === 4 || s === 5;
    btnNext.disabled = (s === 1 && !S.cart.length) || (s === 2 && (S.time == null || !S.date));
  }
  function scrollToStepper() {
    const ui = UI(); const el = $('#stepper');
    if (ui.scrollTo) ui.scrollTo(el, { offset: -(parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--head-h')) || 78) - 8 });
    else scrollTo({ top: Math.max(0, el.getBoundingClientRect().top + scrollY - 110), behavior: 'smooth' });
  }
  function go(step, scroll = true) {
    S.step = step;
    $$('.step').forEach(sec => { const on = +sec.dataset.step === step; sec.hidden = !on; sec.classList.toggle('is-on', on); });
    $$('#stepper li').forEach(li => { const n = +li.dataset.s; li.classList.toggle('is-on', n === step); li.classList.toggle('is-done', n < step); });
    $('#stepper').hidden = step === 5;
    if (step === 2) { ensureAvailability(); buildCal(); buildSlots(); }
    if (step === 4) preparePay();
    nav(); refresh();
    if (scroll) scrollToStepper();
  }
  btnNext.addEventListener('click', () => {
    if (S.step === 1 && S.cart.length) go(2);
    else if (S.step === 2 && S.time != null) go(3);
    else if (S.step === 3 && validateInfos()) go(4);
  });
  btnBack.addEventListener('click', () => go(Math.max(1, S.step - 1)));

  /* ---------- étape 2 : calendrier et créneaux ---------- */
  const calDays = $('#calDays'), calTitle = $('#calTitle'), prev = $('#calPrev'), next = $('#calNext');
  const minStartMs = () => Date.now() + (CFG.MIN_NOTICE_HOURS || 24) * 3600e3;
  const maxKey = () => addDays(todayKey, CFG.MAX_DAYS_AHEAD || 90);
  function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const demoCache = {};
  /* Démonstration : rendez-vous « déjà pris » tirés au hasard (toujours les mêmes pour un jour donné). */
  function demoBusy(k) {
    if (demoCache[k]) return demoCache[k];
    const rs = rangesOf(k); if (!rs.length) return (demoCache[k] = []);
    const r = mulberry(Number(k.replace(/-/g, '')));
    const blocks = [];
    if (r() < 0.08) rs.forEach(x => blocks.push([x[0], x[1]]));      // quelques jours complets
    else {
      const n = r() < 0.5 ? 1 : r() < 0.8 ? 2 : 3;
      for (let i = 0; i < n; i++) {
        const [a, b] = rs[Math.floor(r() * rs.length)];
        const dur = [45, 60, 75, 90][Math.floor(r() * 4)];
        const st = a + Math.floor(r() * Math.max(1, (b - a - dur) / 15)) * 15;
        blocks.push([st, Math.min(b, st + dur)]);
      }
    }
    return (demoCache[k] = blocks);
  }
  function isBusy(k, start, end) {
    if (S.busy) {       // créneaux réels (agenda Google d'Édith)
      const a = parisAt(k, start), b = parisAt(k, end);
      return S.busy.some(([x, y]) => a < +y && b > +x);
    }
    // sans réponse de l'agenda : créneaux fictifs en démonstration, sinon tout est proposé (le Worker et Make revérifient)
    return CFG.DEMO_MODE ? demoBusy(k).some(([x, y]) => start < y && end > x) : false;
  }
  function slotsFor(k) {
    const rs = rangesOf(k); if (!rs.length || !S.cart.length || k > maxKey() || S.loading) return [];
    const dur = totalMin(), step = CFG.SLOT_STEP_MIN || 15, out = [];
    for (const [open, close] of rs) {
      for (let t = open; t + dur <= close; t += step) {
        if (parisAt(k, t) < minStartMs()) continue;
        if (isBusy(k, t, t + dur)) continue;
        out.push(t);
      }
    }
    return out;
  }
  function buildCal() {
    const first = parse(S.month);
    calTitle.textContent = first.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
    prev.disabled = S.month <= monthStart(todayKey);
    next.disabled = addMonths(S.month, 1) > monthStart(maxKey());
    const lead = (first.getDay() + 6) % 7, dim = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
    let h = '';
    for (let b = 0; b < lead; b++) h += '<span class="cday is-blank"></span>';
    for (let n = 1; n <= dim; n++) {
      const k = first.getFullYear() + '-' + pad(first.getMonth() + 1) + '-' + pad(n);
      const ok = slotsFor(k).length > 0;
      h += '<button type="button" class="cday' + (ok ? ' is-open' : '') + (k === todayKey ? ' is-today' : '') + (k === S.date ? ' is-sel' : '') + '" data-k="' + k + '"' + (ok ? '' : ' disabled') + ' aria-label="' + fmtLong(k) + (ok ? ', créneaux disponibles' : ', indisponible') + '">' + n + '</button>';
    }
    calDays.innerHTML = h;
  }
  prev.addEventListener('click', () => { S.month = addMonths(S.month, -1); buildCal(); });
  next.addEventListener('click', () => { S.month = addMonths(S.month, 1); buildCal(); });
  calDays.addEventListener('click', e => {
    const b = e.target.closest('.cday[data-k]'); if (!b || b.disabled) return;
    S.date = b.dataset.k; S.time = null; buildCal(); buildSlots(); refresh();
    if (innerWidth < 900) $('#slotsTitle').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  const slotsGrid = $('#slotsGrid');
  function buildSlots() {
    const t = $('#slotsTitle'), sub = $('#slotsSub');
    if (!S.date) { t.textContent = 'Choisissez un jour'; sub.textContent = 'Durée de votre rendez-vous : environ ' + fmtDur(totalMin()) + '. Les horaires proposés en tiennent compte.'; slotsGrid.innerHTML = ''; return; }
    t.textContent = fmtShort(S.date);
    sub.textContent = 'Rendez-vous d’environ ' + fmtDur(totalMin()) + ' · choisissez l’heure d’arrivée.';
    const s = slotsFor(S.date);
    slotsGrid.innerHTML = S.loading ? '<p class="slots__empty">Chargement des disponibilités…</p>' : s.length ? s.map(m => '<button type="button" class="slot' + (m === S.time ? ' is-sel' : '') + '" role="option" aria-selected="' + (m === S.time) + '" data-t="' + m + '">' + fmtHour(m) + '</button>').join('') : '<p class="slots__empty">Plus de créneau ce jour-là pour cette durée. Essayez un autre jour.</p>';
  }
  slotsGrid.addEventListener('click', e => { const b = e.target.closest('.slot'); if (!b) return; S.time = +b.dataset.t; buildSlots(); refresh(); });

  /* L'agenda n'est interrogé qu'à l'arrivée sur le calendrier (pas à chaque visite de la page : chaque appel fait tourner
     le scénario Make), puis au plus toutes les 2 minutes. */
  let availAt = 0;
  function ensureAvailability() {
    if (!CFG.AVAILABILITY_URL || S.loading || Date.now() - availAt < 120e3) return;
    availAt = Date.now();
    loadAvailability();
  }
  async function loadAvailability() {
    if (!CFG.AVAILABILITY_URL) return;
    S.loading = true;
    try {
      const u = CFG.AVAILABILITY_URL + (CFG.AVAILABILITY_URL.includes('?') ? '&' : '?') + 'from=' + todayKey + '&to=' + maxKey();
      const r = await fetch(u, { cache: 'no-store' }); if (!r.ok) throw new Error(r.status);
      const j = await r.json();
      S.busy = (j.busy || []).map(b => [new Date(Array.isArray(b) ? b[0] : b.start), new Date(Array.isArray(b) ? b[1] : b.end)]).filter(x => !isNaN(x[0]) && !isNaN(x[1]));
    } catch (e) { availAt = 0; /* agenda injoignable : dernière réponse connue conservée, nouvel essai au prochain passage */ }
    S.loading = false;
    if (S.time != null && S.date && !slotsFor(S.date).includes(S.time)) S.time = null; // le créneau choisi pendant le chargement n'est plus libre
    if (S.step === 2) { buildCal(); buildSlots(); }
    nav(); refresh();
  }

  /* ---------- étape 3 : coordonnées ---------- */
  const F = { first: $('#fFirst'), last: $('#fLast'), email: $('#fEmail'), phone: $('#fPhone'), cgv: $('#fCgv') };
  const rules = {
    first: v => (v.trim().length >= 2 ? '' : 'Indiquez votre prénom.'),
    last: v => (v.trim().length >= 2 ? '' : 'Indiquez votre nom.'),
    email: v => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Adresse e-mail invalide.'),
    phone: v => { const d = v.replace(/\D/g, ''); return d.length >= 9 && d.length <= 15 ? '' : 'Numéro de téléphone invalide.'; },
    cgv: () => (F.cgv.checked ? '' : 'Merci de cocher cette case pour continuer.')
  };
  function check(n) {
    const msg = rules[n](n === 'cgv' ? '' : F[n].value);
    const slot = $('[data-err="' + n + '"]'); if (slot) slot.textContent = msg;
    if (n !== 'cgv') F[n].classList.toggle('is-bad', !!msg);
    return msg;
  }
  ['first', 'last', 'email', 'phone'].forEach(n => { F[n].addEventListener('blur', () => check(n)); F[n].addEventListener('input', () => { if (F[n].classList.contains('is-bad')) check(n); }); });
  function validateInfos() {
    let bad = ''; ['first', 'last', 'email', 'phone', 'cgv'].forEach(n => { if (check(n) && !bad) bad = n; });
    if (bad) { F[bad].focus(); return false; }
    return true;
  }

  /* ---------- étape 4 : règlement ---------- */
  const payBtn = $('#payBtn'), payMsg = $('#payMsg'), modal = $('#payModal'), payOpts = $('#payOpts');
  function payChoices() {
    const t = total(), dc = depositCents(t), out = [];
    if (onlineAllowed()) {
      out.push({ id: 'deposit', title: 'Régler un acompte de ' + POL.depositPct + ' %', small: 'Le solde se règle à l’institut', amt: eurC(dc) });
      out.push({ id: 'full', title: 'Régler la totalité maintenant', small: 'Rien à payer à l’institut', amt: eur(t) });
    }
    out.push({ id: 'onsite', title: 'Régler à l’institut', small: allPriced() ? 'Confirmer sans paiement en ligne' : 'Tarif confirmé par Édith, règlement sur place', amt: '' });
    return out;
  }
  function preparePay() {
    const ch = payChoices();
    if (!ch.some(c => c.id === S.pay)) S.pay = ch[0].id;
    payOpts.innerHTML = '<legend class="sr">Mode de règlement</legend>' + ch.map(c => '<label class="payopt' + (c.id === S.pay ? ' is-on' : '') + '"><input type="radio" name="pay" value="' + c.id + '"' + (c.id === S.pay ? ' checked' : '') + '><span>' + c.title + '<small>' + c.small + '</small></span><b>' + c.amt + '</b></label>').join('');
    payMsg.textContent = '';
    updatePay();
  }
  payOpts.addEventListener('change', e => { if (e.target.name === 'pay') { S.pay = e.target.value; $$('.payopt', payOpts).forEach(l => l.classList.toggle('is-on', $('input', l).checked)); updatePay(); } });
  function dueCents() { const t = total(); return S.pay === 'deposit' ? depositCents(t) : S.pay === 'full' ? t * 100 : 0; }
  function updatePay() {
    const t = total(), due = dueCents();
    $('#payLabel').textContent = S.pay === 'onsite' ? 'Rien à payer en ligne' : 'À régler maintenant';
    $('#payAmount').textContent = S.pay === 'onsite' ? '0\u00a0€' : eurC(due).replace(' ', '\u00a0');
    $('#payRest').textContent = S.pay === 'deposit' ? 'Solde de ' + eurC(t * 100 - due) + ' à régler à l’institut : carte bancaire, espèces ou chèque.'
      : S.pay === 'full' ? 'Votre rendez-vous est entièrement réglé.'
      : 'Vous réglez le jour du soin, à l’institut' + (unpricedCount() ? ' : le tarif des soins « sur demande » est confirmé par Édith.' : '.');
    const label = payBtn.querySelector('span');
    label.textContent = S.pay === 'onsite' ? 'Confirmer le rendez-vous' : S.pay === 'deposit' ? 'Payer l’acompte de ' + eurC(due) : 'Payer ' + eurC(due);
    payBtn.querySelector('use').setAttribute('href', S.pay === 'onsite' ? '#i-check' : '#i-lock');
  }
  const refChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  function makeRef() { return 'BP-' + S.date.replace(/-/g, '').slice(2) + '-' + Array.from({ length: 4 }, () => refChars[Math.floor(Math.random() * 32)]).join(''); }
  function booking() {
    const items = S.cart.map(id => ({ id, name: ITEMS[id].name, min: ITEMS[id].min, price: ITEMS[id].price }));
    const t = total();
    return {
      ref: S.ref || (S.ref = makeRef()), date: S.date, start: hhmm(S.time), startMin: S.time, durationMin: totalMin(),
      timezone: 'Europe/Paris', startLocal: S.date + 'T' + hhmm(S.time) + ':00', endLocal: S.date + 'T' + hhmm(S.time + totalMin()) + ':00',
      items, total: t, payment: S.pay, depositCents: S.pay === 'deposit' ? depositCents(t) : 0, cancelHours: POL.cancelHours,
      first: F.first.value.trim(), last: F.last.value.trim(), email: F.email.value.trim(), phone: F.phone.value.trim(),
      visit: ($('input[name=visit]:checked') || {}).value || 'new', message: $('#fMsg').value.trim(), locale: 'fr', page: location.href.split('?')[0].split('#')[0], sentAt: new Date().toISOString()
    };
  }
  async function post(path, body) {
    if (!CFG.WORKER_URL) throw new Error('config');
    const r = await fetch(CFG.WORKER_URL.replace(/\/+$/, '') + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(j.error || 'send'); e.status = r.status; e.data = j; throw e; }
    return j;
  }
  payBtn.addEventListener('click', async () => {
    if (S.sending) return;
    const b = booking();
    if ($('#fHp').value || $('#fHp2').value) { finish(b, { demo: true }); return; }          // pot de miel
    const mode = CFG.PAYMENT_MODE || 'demo';
    if (mode === 'demo') {
      if (S.pay === 'onsite') { finish(b, { demo: true, onsite: true }); return; }
      $('#payModalAmount').textContent = eurC(dueCents()); openModal(); return;
    }
    S.sending = true; payBtn.disabled = true; payMsg.textContent = '';
    try {
      if (S.pay === 'onsite' || mode === 'onsite') {
        await post('/book', Object.assign(b, { payment: 'onsite' }));
        finish(b, { onsite: true });
      } else {
        sessionStorage.setItem('bap-pending', JSON.stringify(b));
        const j = await post('/checkout', b);
        if (!j.url) throw new Error('checkout');
        location.href = j.url; return;
      }
    } catch (err) {
      const conflict = err.status === 409 || err.message === 'conflict';
      payMsg.textContent = conflict ? 'Ce créneau vient d’être pris. Merci d’en choisir un autre.' : 'La demande n’a pas pu aboutir. Appelez le ' + (CFG.PHONE_DISPLAY || '') + ' ou réessayez dans un instant.';
      if (conflict) { S.time = null; go(2); }
    } finally { S.sending = false; payBtn.disabled = false; }
  });

  /* ---------- fenêtres (paiement de démonstration, carte cadeau) ---------- */
  let lastFocus = null;
  function showModal(el, focusEl) {
    lastFocus = document.activeElement; el.hidden = false; document.body.classList.add('modal-open');
    const ui = UI(); if (ui.lenis) ui.lenis.stop();
    setTimeout(() => focusEl && focusEl.focus(), 30);
  }
  function hideModal(el) {
    el.hidden = true; if ($$('.modal').every(m => m.hidden)) { document.body.classList.remove('modal-open'); const ui = UI(); if (ui.lenis) ui.lenis.start(); }
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function openModal() { showModal(modal, $('#payModalOk')); }
  function closeModal() { hideModal(modal); }
  $('#payModalCancel').addEventListener('click', closeModal);
  $('#payModalOk').addEventListener('click', () => { closeModal(); finish(booking(), { demo: true }); });
  addEventListener('keydown', e => { if (e.key === 'Escape') $$('.modal').forEach(m => { if (!m.hidden) hideModal(m); }); });
  $$('.modal').forEach(m => m.addEventListener('click', e => { if (e.target === m) hideModal(m); }));

  /* ---------- confirmation + agenda de la cliente ---------- */
  const icsEsc = s => String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
  const stamp = (k, min) => k.replace(/-/g, '') + 'T' + pad(Math.floor(min / 60)) + pad(min % 60) + '00';
  function fold(line) { const out = []; while (line.length > 72) { out.push(line.slice(0, 72)); line = ' ' + line.slice(72); } out.push(line); return out.join('\r\n'); }
  function finish(b, opt) {
    opt = opt || {};
    S.step = 5;
    $$('.step').forEach(sec => { const on = +sec.dataset.step === 5; sec.hidden = !on; sec.classList.toggle('is-on', on); });
    $('#stepper').hidden = true; $('#flowSide').hidden = true;
    $('#doneTitle').textContent = opt.demo ? 'Rendez-vous préparé' : 'Rendez-vous confirmé';
    const when = fmtLong(b.date) + ' à ' + b.start.replace(':', '\u00a0h\u00a0');
    const owner = CFG.OWNER || 'Édith';
    $('#doneText').textContent = opt.demo
      ? 'Merci ' + b.first + ' ! Voici le récapitulatif de votre rendez-vous du ' + when + '. Une fois la page reliée à l’agenda d’' + owner + ' et à Stripe, ce même parcours enregistre le créneau' + (opt.onsite ? '.' : ' et encaisse le règlement.')
      : 'Merci ' + b.first + ' ! ' + owner + ' vous attend le ' + when + (opt.onsite ? '. Le règlement se fait à l’institut.' : opt.paid ? '. Votre règlement est bien reçu.' : '.') + ' Un e-mail de confirmation vous a été envoyé.';
    const pay = b.payment === 'deposit' ? 'Acompte ' + eurC(depositCents(b.total)) : b.payment === 'full' ? 'Réglé ' + eur(b.total) : 'À l’institut';
    $('#doneSum').innerHTML = [['Date', fmtShort(b.date)], ['Heure', b.start.replace(':', '\u00a0h\u00a0')], ['Durée', 'env. ' + fmtDur(b.durationMin)], ['Règlement', pay], ['Adresse', CFG.ADDRESS || ''], ['Référence', b.ref]].map(r => '<div><dt>' + r[0] + '</dt><dd>' + r[1] + '</dd></div>').join('');
    $('#doneDemo').hidden = !opt.demo;
    const names = b.items.map(i => i.name).join(', ');
    const cancel = 'Annulation ou déplacement gratuits jusqu’à ' + POL.cancelHours + ' h avant le rendez-vous.';
    const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//La Boite a Parfums//Reservation//FR', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'BEGIN:VEVENT', 'UID:' + b.ref + '@boite-a-parfums', 'DTSTAMP:' + new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''),
      'DTSTART;TZID=Europe/Paris:' + stamp(b.date, b.startMin), 'DTEND;TZID=Europe/Paris:' + stamp(b.date, b.startMin + b.durationMin), 'SUMMARY:' + icsEsc('Rendez-vous La Boîte à Parfums'), 'LOCATION:' + icsEsc(CFG.ADDRESS || ''),
      'DESCRIPTION:' + icsEsc(names + ' · Réf. ' + b.ref + ' · ' + (CFG.PHONE_DISPLAY || '') + ' · ' + cancel), 'END:VEVENT', 'END:VCALENDAR'];
    const a = $('#btnIcs'); if (a.dataset.u) URL.revokeObjectURL(a.dataset.u);
    a.href = URL.createObjectURL(new Blob([lines.map(fold).join('\r\n')], { type: 'text/calendar;charset=utf-8' })); a.dataset.u = a.href; a.download = 'rendez-vous-boite-a-parfums-' + b.date + '.ics';
    $('#btnGcal').href = 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' + encodeURIComponent('Rendez-vous La Boîte à Parfums') + '&dates=' + stamp(b.date, b.startMin) + '/' + stamp(b.date, b.startMin + b.durationMin) + '&location=' + encodeURIComponent(CFG.ADDRESS || '') + '&details=' + encodeURIComponent(names + ' · Réf. ' + b.ref) + '&ctz=Europe/Paris';
    $('#btnRoute').href = 'https://www.google.com/maps/dir/?api=1&destination=' + (CFG.LAT || 43.9163) + ',' + (CFG.LNG || 5.919);
    $('#done').hidden = false;
    scrollToStepper();
  }
  $('#doneNew').addEventListener('click', () => { S.cart = []; S.date = null; S.time = null; S.ref = ''; $('#flowSide').hidden = false; go(1, true); });

  /* ---------- carte cadeau ---------- */
  const G = { amount: 50, sending: false };
  const gModal = $('#giftModal');
  const amounts = (CFG.GIFT_AMOUNTS && CFG.GIFT_AMOUNTS.length ? CFG.GIFT_AMOUNTS : [30, 50, 80, 120]);
  function renderGiftChips() {
    const html = amounts.map(a => '<button type="button" data-a="' + a + '" class="' + (a === G.amount ? 'is-on' : '') + '" aria-pressed="' + (a === G.amount) + '">' + a + '&nbsp;€</button>').join('');
    $('#giftAmounts').innerHTML = html; $('#giftAmountsModal').innerHTML = html;
    $('#giftCardAmt').textContent = G.amount;
    const lab = $('#giftPay span'); if (lab) lab.textContent = 'Payer ' + eur(G.amount);
  }
  function setGift(a, fromCustom) {
    a = Math.round(a);
    if (!(a >= (CFG.GIFT_MIN || 20) && a <= (CFG.GIFT_MAX || 300))) return;
    G.amount = a; renderGiftChips();
    if (!fromCustom) $('#giftCustom').value = amounts.includes(a) ? '' : a;
  }
  ['#giftAmounts', '#giftAmountsModal'].forEach(sel => $(sel).addEventListener('click', e => { const b = e.target.closest('button[data-a]'); if (b) setGift(+b.dataset.a); }));
  $('#giftCustom').addEventListener('input', e => { const v = parseInt(e.target.value, 10); if (v >= (CFG.GIFT_MIN || 20) && v <= (CFG.GIFT_MAX || 300)) setGift(v, true); });
  $('#giftOpen').addEventListener('click', () => { $('#giftForm').hidden = false; $('#giftDone').hidden = true; $('#giftMsgErr').textContent = ''; showModal(gModal, $('#giftFrom')); });
  $('#giftClose').addEventListener('click', () => hideModal(gModal));
  $('#giftDoneOk').addEventListener('click', () => hideModal(gModal));
  const gField = { from: $('#giftFrom'), email: $('#giftEmail') };
  const gRule = { from: v => (v.trim().length >= 2 ? '' : 'Indiquez votre nom.'), email: v => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Adresse e-mail invalide.') };
  function gCheck(k) { const m = gRule[k](gField[k].value); $('[data-gerr="' + k + '"]').textContent = m; gField[k].classList.toggle('is-bad', !!m); return m; }
  Object.keys(gField).forEach(k => gField[k].addEventListener('input', () => { if (gField[k].classList.contains('is-bad')) gCheck(k); }));
  function giftValid() {
    let ok = true;
    Object.keys(gField).forEach(k => { if (gCheck(k)) { if (ok) gField[k].focus(); ok = false; } });
    return ok;
  }
  function giftCode() { return 'BP-' + Array.from({ length: 2 }, () => Array.from({ length: 4 }, () => refChars[Math.floor(Math.random() * 32)]).join('')).join('-'); }
  function giftDone(g, demo) {
    $('#giftForm').hidden = true; $('#giftDone').hidden = false;
    $('#giftDoneText').textContent = demo ? 'Voici la carte cadeau de ' + eur(g.amount) + ' que ' + g.from.split(' ')[0] + ' recevrait par e-mail, à offrir' + (g.to ? ' à ' + g.to : '') + '.' : 'Merci ' + g.from.split(' ')[0] + ' ! La carte cadeau de ' + eur(g.amount) + ' vous est envoyée par e-mail à ' + g.email + '.';
    $('#giftCode').textContent = g.code || '';
    $('#giftCode').hidden = !g.code;
    $('#giftDemo').hidden = !demo;
  }
  $('#giftPay').addEventListener('click', async () => {
    if (G.sending) return;
    if ($('#giftHp').value) return;
    if (!giftValid()) return;
    const g = { amount: G.amount, from: gField.from.value.trim(), email: gField.email.value.trim(), to: $('#giftTo').value.trim(), message: $('#giftMsg').value.trim(), ref: 'CG-' + Array.from({ length: 6 }, () => refChars[Math.floor(Math.random() * 32)]).join(''), page: location.href.split('?')[0].split('#')[0] };
    const mode = CFG.PAYMENT_MODE || 'demo';
    if (mode !== 'stripe') { g.code = giftCode(); giftDone(g, true); return; }
    G.sending = true; $('#giftPay').disabled = true; $('#giftMsgErr').textContent = '';
    try {
      sessionStorage.setItem('bap-gift', JSON.stringify(g));
      const j = await post('/gift', g);
      if (!j.url) throw new Error('gift');
      location.href = j.url;
    } catch (e) { $('#giftMsgErr').textContent = 'Le paiement n’a pas pu être lancé. Appelez le ' + (CFG.PHONE_DISPLAY || '') + ' ou réessayez dans un instant.'; }
    finally { G.sending = false; $('#giftPay').disabled = false; }
  });

  /* ---------- API publique + démarrage ---------- */
  function openGroup(id) {
    if (!ITEMS || !D.groups.some(g => g.id === id)) id = S.group;
    setGroup(id);
    if (S.step !== 1) go(1, false);
    const ui = UI();
    setTimeout(() => { if (ui.scrollTo) ui.scrollTo('#reserver'); else $('#reserver').scrollIntoView({ behavior: 'smooth' }); }, 40);
  }
  window.BAP_Booking = { openGroup };

  if (CFG.DEMO_MODE) { const b = $('#demoBanner'); if (b) b.hidden = false; }
  buildMenu(); renderGiftChips(); refresh(); nav();

  // retour de Stripe
  const qs = new URLSearchParams(location.search);
  const readKey = k => { try { return JSON.parse(sessionStorage.getItem(k) || 'null'); } catch (e) { return null; } };
  if (qs.get('paiement') === 'ok') {
    const b = readKey('bap-pending');
    if (b && b.ref === qs.get('ref')) { sessionStorage.removeItem('bap-pending'); finish(b, { paid: true }); }
  } else if (qs.get('paiement') === 'annule') {
    const b = readKey('bap-pending');
    if (b) { S.cart = b.items.map(i => i.id).filter(id => ITEMS[id]); S.date = b.date; S.time = b.startMin; S.pay = b.payment || 'deposit'; F.first.value = b.first; F.last.value = b.last; F.email.value = b.email; F.phone.value = b.phone; F.cgv.checked = true; go(4, false); payMsg.textContent = 'Le paiement a été annulé. Vous pouvez réessayer.'; }
  } else if (qs.get('cadeau') === 'ok') {
    const g = readKey('bap-gift');
    if (g && g.ref === qs.get('ref')) { sessionStorage.removeItem('bap-gift'); G.amount = g.amount; showModal(gModal, $('#giftDoneOk')); giftDone(g, false); }
  }
})();

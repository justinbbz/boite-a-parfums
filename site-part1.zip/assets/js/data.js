/* La Boîte à Parfums — données du site (carte des soins, horaires, règles, avis).
   Lues par la réservation (booking.js) ET par le Worker de paiement (worker/build-catalog.mjs).
   Après toute modification : node worker/build-catalog.mjs, puis cd worker && npm test.

   ┌─ À VALIDER AVEC ÉDITH AVANT TOUTE MISE EN LIGNE ─────────────────────────────────────────────────────┐
   │ • PRIX  : aucun tarif de soin n'est publié sur Facebook, Google ni PagesJaunes. Les seuls prix connus   │
   │   (price: nombre) viennent de l'annuaire Koifaire, texte NON DATÉ et probablement ancien. Tout le reste │
   │   est « sur demande » (price: null) : rien n'a été inventé. Le tableau des tarifs encadré à l'accueil   │
   │   de l'institut (photo Facebook 1815485702753074, prix illisibles) donne les NOMS des épilations et des │
   │   soins des mains / pieds.                                                                              │
   │ • DURÉES (min) : estimations, non communiquées par l'institut.                                          │
   │ • RÈGLES : acompte 30 %, annulation gratuite jusqu'à 24 h avant, retard toléré 15 min : propositions.   │
   └──────────────────────────────────────────────────────────────────────────────────────────────────────┘ */
window.BAP = {
  /* ---------- règles ---------- */
  policy: { depositPct: 30, cancelHours: 24, lateArrivalMin: 15 },

  /* ---------- horaires (Google Maps = PagesJaunes, 14/10/2026) : 0 = dimanche … 6 = samedi ---------- */
  hours: {
    0: null,
    1: null,
    2: [['09:00', '12:00'], ['14:00', '19:00']],
    3: [['09:00', '12:00'], ['14:00', '19:00']],
    4: [['09:00', '12:00'], ['14:00', '19:00']],
    5: [['09:00', '12:00'], ['14:00', '19:00']],
    6: [['09:00', '12:00'], ['14:00', '18:00']]
  },

  /* ---------- carte des soins ----------
     price : euros entiers, ou null = « sur demande » (réservable, règlement à l'institut)
     priceSource : d'où vient le prix (voir l'encadré ci-dessus)  ·  min : durée estimée en minutes */
  groups: [
    {
      id: 'visage', title: 'Soins du visage', kicker: 'Sothys Paris', from: null,
      intro: 'Les soins Sothys, maison française fondée en 1946 et réservée aux instituts. Édith choisit avec vous le soin qui convient à votre peau.',
      items: [
        { id: 'nettoyage-peau', name: 'Nettoyage de peau', price: 25, min: 45, priceSource: 'koifaire', desc: 'Le geste de base pour une peau nette, douce et lumineuse.' },
        { id: 'soin-destressant', name: 'Soin déstressant du visage', price: 55, min: 60, priceSource: 'koifaire', desc: 'Un soin relaxant pour relâcher les tensions du visage et retrouver une peau apaisée.' },
        { id: 'soin-gourmand', name: 'Soin gourmand · cacao & éclats de coco', price: 55, min: 60, priceSource: 'koifaire', desc: 'Relaxant, nutritif, réhydratant : un soin tout en gourmandise.' },
        { id: 'soin-saison', name: 'Soin de saison Sothys', price: null, min: 60, desc: 'Le soin saisonnier de la maison Sothys, au fil des collections et des envies de votre peau.' }
      ]
    },
    {
      id: 'regard', title: 'Regard & maquillage', kicker: 'Le regard', from: null,
      intro: 'Un regard sublimé, un teint lumineux, un maquillage qui vous ressemble, pour le quotidien comme pour les grands jours.',
      items: [
        { id: 'rehaussement-cils', name: 'Rehaussement de cils', price: null, min: 60, desc: 'Des cils recourbés et allongés, sans extensions : le regard ouvert pour des semaines.' },
        { id: 'maquillage-jour', name: 'Maquillage du jour', price: 13, min: 30, priceSource: 'koifaire', desc: 'Un maquillage frais et naturel, avec les collections Sothys.' },
        { id: 'maquillage-mariee', name: 'Maquillage de mariée', price: null, min: 90, desc: 'Un maquillage délicat pour le plus beau des jours.' }
      ]
    },
    {
      id: 'corps', title: 'Corps & massages', kicker: 'Détente', from: null,
      intro: 'Massages, rituels et soins de la silhouette : un vrai moment de détente.',
      items: [
        { id: 'massage-corps', name: 'Massage du corps', price: null, min: 60, desc: 'Un massage relaxant pour dénouer les tensions.' },
        { id: 'rituel-bougies', name: 'Rituel relaxant aux bougies', price: 69, min: 75, priceSource: 'koifaire', desc: 'Un rituel relaxant et régénérant, à la lueur des bougies et des essences.' },
        { id: 'star-vac', name: 'Soin amincissant · palper-rouler Star Vac', price: null, min: 45, desc: 'Le palper-rouler pour affiner la silhouette.' }
      ]
    },
    {
      id: 'epilations', title: 'Épilations', kicker: 'Dès 7 €', from: 7,
      intro: 'Des épilations réalisées avec soin, dans le calme d’une cabine impeccable. À partir de 7 €.',
      items: [
        { id: 'epil-levres', name: 'Lèvres', price: null, min: 10 },
        { id: 'epil-sourcils', name: 'Sourcils', price: null, min: 15 },
        { id: 'epil-levres-sourcils', name: 'Lèvres et sourcils', price: null, min: 20 },
        { id: 'epil-visage', name: 'Visage', price: null, min: 25 },
        { id: 'epil-aisselles', name: 'Aisselles', price: null, min: 10 },
        { id: 'epil-maillot-integral', name: 'Maillot intégral', price: null, min: 25 },
        { id: 'epil-demi-jambes', name: 'Demi-jambes', price: null, min: 30 },
        { id: 'epil-cuisses', name: 'Cuisses', price: null, min: 25 },
        { id: 'epil-jambes', name: 'Jambes complètes', price: null, min: 45 },
        { id: 'epil-jambes-maillot-aisselles', name: 'Jambes complètes, maillot et aisselles', price: null, min: 75 }
      ]
    },
    {
      id: 'mains', title: 'Mains & pieds', kicker: 'Beauté des ongles', from: null,
      intro: 'Mains soignées, ongles sublimés : beauté des mains et des pieds, vernis classique ou semi-permanent.',
      items: [
        { id: 'beaute-mains', name: 'Beauté des mains', price: null, min: 45 },
        { id: 'pose-vernis', name: 'Pose de vernis', price: null, min: 20 },
        { id: 'pose-french', name: 'Pose de vernis French manucure', price: null, min: 30 },
        { id: 'pose-semi', name: 'Pose de vernis semi-permanent', price: null, min: 45 },
        { id: 'coupe-ongles', name: 'Coupe et limage des ongles', price: null, min: 15 },
        { id: 'beaute-pieds', name: 'Beauté des pieds', price: null, min: 60 }
      ]
    }
  ],

  /* ---------- avis Google (extraits fidèles ; ponctuation corrigée ; prénom + initiale) ---------- */
  rating: { value: 4.8, count: 30 },
  reviews: [
    { name: 'Morgane G.', guide: true, when: 'mai 2026', text: 'J’ai eu la chance de profiter d’un soin du visage dans cet institut et je suis ravie de mon expérience. Un moment de détente très agréable du début à la fin.' },
    { name: 'Janine G.', when: 'février 2026', text: 'Je vous recommande cet institut : c’est un endroit chaleureux où l’on est très bien reçu. Les soins sont efficaces et faits avec douceur.' },
    { name: 'Sabine E.', when: 'mai 2024', text: 'L’accueil est chaleureux et la qualité des soins est excellente. J’avais déjà testé les soins de saison à plusieurs reprises.' },
    { name: 'Audrey D.', when: 'février 2021', text: 'Cliente depuis maintenant 11 ans, et pour rien au monde je changerais. Très agréable, très douce, très propre, hygiène garantie. Le point très positif : sa discrétion.' },
    { name: 'Noémi', guide: true, when: 'novembre 2022', text: 'Sous les doigts d’Édith ou de son assistante, vous pourrez vous détendre et passer un agréable moment.' },
    { name: 'Caroline G.', guide: true, text: 'Très accueillant, soins de qualité, discrétion assurée, cabines très propres. Je recommande cet établissement.' },
    { name: 'Michèle D.', when: 'décembre 2022', text: 'Institut très propre avec une ambiance chaleureuse, sans oublier l’accueil et la douceur de l’esthéticienne. Je recommande.' },
    { name: 'Lydie C.', guide: true, when: 'septembre 2021', text: 'Très professionnelle. Toujours le sourire. Très propre. Parfait quoi.' },
    { name: 'Graziella B.', guide: true, when: 'janvier 2023', text: 'Parfait ! Super moment de détente, comme toujours.' }
  ]
};

/* Réglages du site La Boîte à Parfums : seul fichier à modifier pour brancher l'agenda et le paiement.
   Voir RESERVATION-AGENDA.md (agenda Google via Make) et worker/README.md (paiement Stripe, cartes cadeaux).
   Les soins, prix, durées, horaires et règles sont dans data.js ; vérification : node outils/verifier-donnees.mjs */
window.BAP_CONFIG = {
  /* true = démonstration : créneaux d'exemple, aucun paiement réel, aucune demande envoyée. */
  DEMO_MODE: true,

  /* Agenda Google d'Édith (via Make). Contrat décrit dans RESERVATION-AGENDA.md. */
  AVAILABILITY_URL: '',     // renvoie les créneaux déjà pris (GET ?from=AAAA-MM-JJ&to=AAAA-MM-JJ)

  /* Worker Cloudflare (worker/) : paiement Stripe, rendez-vous sans paiement, cartes cadeaux.
     Ex. https://boite-a-parfums-paiement.<compte>.workers.dev  (sans « / » final) */
  WORKER_URL: '',

  /* Moyen de règlement proposé à l'étape 4 :
     'demo'   : simulation claire, aucune carte demandée (état actuel)
     'stripe' : acompte ou totalité par carte (Stripe Checkout) + option « régler à l'institut »
     'onsite' : aucune carte en ligne, le rendez-vous est enregistré et se règle à l'institut */
  PAYMENT_MODE: 'demo',

  /* Réservation. Créneaux de 15 min ; délai minimum avant un rendez-vous. */
  MIN_NOTICE_HOURS: 24,
  MAX_DAYS_AHEAD: 90,
  SLOT_STEP_MIN: 15,
  MAX_TOTAL_MIN: 240,

  /* Carte cadeau : montants proposés (€) et limites du montant libre. */
  GIFT_AMOUNTS: [30, 50, 80, 120],
  GIFT_MIN: 20,
  GIFT_MAX: 300,

  /* Institut */
  BRAND: 'La Boîte à Parfums',
  OWNER: 'Édith',
  PHONE_DISPLAY: '04 92 78 77 87',
  PHONE_TEL: '+33492787787',
  EMAIL: 'ea04@free.fr',
  ADDRESS: '9 allée Léon Masse, 04700 Oraison',
  LAT: 43.9163479,
  LNG: 5.9189922,
  FACEBOOK: 'https://www.facebook.com/profile.php?id=100028749859646',
  GOOGLE_MAPS: 'https://www.google.com/maps/search/?api=1&query=La+boite+%C3%A0+Parfums+9+all%C3%A9e+L%C3%A9on+Masse+04700+Oraison'
};
